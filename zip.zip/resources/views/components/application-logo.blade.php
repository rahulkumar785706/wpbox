<a class="navbar-brand pt-0" href="/">
  <img src="{{ config('settings.logo') }}" class="navbar-brand-img h-10" alt="...">
</a>
