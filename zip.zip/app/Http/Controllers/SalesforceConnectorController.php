<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class SalesforceConnectorController extends Controller
{
    /**
     * Send WhatsApp Message to Salesforce.
     */
    public function sendWhatsAppMessage(Request $request)
    {
        $url = env('SALESFORCE_API_URL');
        return response()->json($url);
        // Collect data from the request
        $data = [
            'phone' => $request->input('phone'),
            'message' => $request->input('message', 'Hello, this is a default message.'),
            'sentAt' => $request->input('sentAt'),
            'mediaUrl' => $request->input('mediaUrl'),
            'messageId' => $request->input('messageId'),
            'status' => $request->input('status'),
            'customerName' => $request->input('customerName'),
            'countryCode' => $request->input('countryCode'),
        ];

        // Build the query parameter
        $queryParam = http_build_query(['data' => json_encode($data)]);

        try {
            // Send the GET request to Salesforce API
            $response = Http::get($url . '?' . $queryParam);

            // Check if the response is successful
            if ($response->successful()) {
                return response()->json([
                    'message' => 'Message sent successfully!',
                    'salesforce_response' => $response->body(),
                ], 200);
            }

            // Handle failure responses
            return response()->json([
                'message' => 'Failed to send the message.',
                'error' => $response->body(),
            ], $response->status());
        } catch (\Exception $e) {
            // Handle exceptions
            return response()->json([
                'message' => 'An error occurred while sending the message.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
