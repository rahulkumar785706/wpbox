<?php

return [
    'success' => 'Success',
    'close' => 'Close',
];
