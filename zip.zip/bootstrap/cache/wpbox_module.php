<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Wpbox\\Providers\\Main',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Wpbox\\Providers\\Main',
  ),
  'deferred' => 
  array (
  ),
);