<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Dashboard\\Providers\\Main',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Dashboard\\Providers\\Main',
  ),
  'deferred' => 
  array (
  ),
);