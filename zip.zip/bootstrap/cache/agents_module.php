<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Agents\\Providers\\Main',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Agents\\Providers\\Main',
  ),
  'deferred' => 
  array (
  ),
);