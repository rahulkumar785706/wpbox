<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Contacts\\Providers\\Main',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Contacts\\Providers\\Main',
  ),
  'deferred' => 
  array (
  ),
);